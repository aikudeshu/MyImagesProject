
class Global{
    baseURL= "http://imageuploadbackend.herokuapp.com/";
    //baseURL= "http://localhost:8080/";
    loggedUserID = "92";
}

export default _global = new Global();